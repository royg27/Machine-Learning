﻿using System.Collections;
using System.Collections.Generic;
using MLAgents;
using UnityEngine;
namespace UnityStandardAssets.Vehicles.Car {

    [RequireComponent(typeof(CarController))]

    public class MyCar_script : Agent
    {
        public GameObject target;
        public CarController controller;

        public override void AgentAction(float[] vectorAction, string textAction)
        {
            if (brain.brainParameters.vectorActionSpaceType == SpaceType.continuous)
            {
                controller.Move(vectorAction[0], 1f, 0f, 0f);
            }
            //
            //TODO: define reward
        }

        public override void CollectObservations()
        {
            //rotation of car
            AddVectorObs(gameObject.transform.rotation.z);
            AddVectorObs(gameObject.transform.rotation.x);
            //manhetten dist from target
            AddVectorObs((gameObject.transform.position.x - target.transform.position.x));
            AddVectorObs((gameObject.transform.position.y - target.transform.position.y));
            AddVectorObs((gameObject.transform.position.z - target.transform.position.z));


        }

        public override void AgentReset()
        {
            base.AgentReset();
        }

    }
}