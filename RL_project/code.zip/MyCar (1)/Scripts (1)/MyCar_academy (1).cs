﻿using System.Collections;
using System.Collections.Generic;
using MLAgents;
using UnityEngine;

public class MyCar_academy : Academy
{
    private int num_steps = 0;
    public override void InitializeAcademy()
    {
        Monitor.SetActive(true);
    }

    public override void AcademyReset()
    {
        base.AcademyReset();
    }

    public override void AcademyStep()
    {

        base.AcademyStep();
    }
}
