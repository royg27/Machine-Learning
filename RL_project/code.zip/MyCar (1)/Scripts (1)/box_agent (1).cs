﻿using UnityEngine;
using Random = UnityEngine.Random;
using MLAgents;
using System;

public class box_agent : Agent
{
    public GameObject area;
    private PyramidArea myArea;
    private Rigidbody agentRb;
    private RayPerception rayPer;
    private Vector3 start_pos;
    public GameObject target;
    public bool is_randomize = false;

    public override void InitializeAgent()
    {
        base.InitializeAgent();
        agentRb = GetComponent<Rigidbody>();
        myArea = area.GetComponent<PyramidArea>();
        rayPer = GetComponent<RayPerception>();
        start_pos = gameObject.transform.localPosition;
    }

    public override void CollectObservations()
    {
        const float rayDistance = 35f;
        float[] rayAngles = {20f, 90f, 160f, 45f, 135f, 70f, 110f};
        float[] rayAngles1 = {25f, 95f, 165f, 50f, 140f, 75f, 115f};
        float[] rayAngles2 = {15f, 85f, 155f, 40f, 130f, 65f, 105f};

        string[] detectableObjects = {"wall", "target", "Player"};   //todo change target to known
        AddVectorObs(rayPer.Perceive(rayDistance, rayAngles, detectableObjects, 0f, 0f));
        //AddVectorObs(rayPer.Perceive(rayDistance, rayAngles1, detectableObjects, 0f, 5f));
        //AddVectorObs(rayPer.Perceive(rayDistance, rayAngles2, detectableObjects, 0f, 10f));
        AddVectorObs(transform.InverseTransformDirection(agentRb.velocity));

        //dir to target normalized
        var heading = target.transform.position - gameObject.transform.position;
        var distance = heading.magnitude;
        var direction_to_target = heading / distance; // This is now the normalized direction.
        AddVectorObs(direction_to_target);
        AddVectorObs(transform.transform.forward);
    }

    public void MoveAgent(float[] act)
    {
        var dirToGo = Vector3.zero;
        var rotateDir = Vector3.zero;
        var action = Mathf.FloorToInt(act[0]);
        switch (action)
        {
            case 1:
                dirToGo = transform.forward * 1f;
                break;
            case 2:
                dirToGo = transform.forward * -1f;
                break;
            case 3:
                rotateDir = transform.up * 1f;
                break;
            case 4:
                rotateDir = transform.up * -1f;
                break;
        }

        transform.Rotate(rotateDir, Time.deltaTime * 200f);
        agentRb.AddForce(dirToGo * 1f, ForceMode.VelocityChange);   //was 2f

        //
        float dist_from_target = Vector3.Distance(gameObject.transform.position, target.transform.position);
        //reached target
        if (dist_from_target < 15)
        {
            SetReward(2f);
            Done();
            print("target reached!");

        }
    }

    public override void AgentAction(float[] vectorAction, string textAction)
    {
        if (IsDone())
        {
            return;
        }
        AddReward(-1f / agentParameters.maxStep);
        MoveAgent(vectorAction);
    }

    public override void AgentReset()
    {
        


        Vector3 random_loc_x;
        Vector3 random_loc_z;
        if (is_randomize)
        {
            agentRb.velocity = Vector3.zero;
            transform.rotation = Quaternion.Euler(new Vector3(0f, Random.Range(0, 360)));
            gameObject.transform.localPosition = start_pos + new Vector3(Random.Range(-10f, 10f), 0f, Random.Range(-10f, 10f));

            float x_val = gameObject.transform.localPosition.x;
            float z_val = gameObject.transform.localPosition.z;

            if (Math.Abs(x_val) < 25 && z_val < 30)
            {
                //top corner
                random_loc_x = new Vector3(Random.Range(-65f, 65f), 0f, 0f);
                if (Math.Abs(random_loc_x.x) > 25)
                {
                    random_loc_z = new Vector3(0f, 0f, Random.Range(70f, 80f));
                }
                else
                {
                    random_loc_z = new Vector3(0f, 0f, Random.Range(120f, 130f));
                }
            }
            else if (x_val < -35 && z_val < 90 && z_val > 60)
            {
                //right corner
                random_loc_z = new Vector3(0f, 0f, Random.Range(10f, 140f));
                if (random_loc_z.z < 80f && random_loc_z.z > 70f)
                {
                    random_loc_x = new Vector3(Random.Range(45f, 65f), 0f, 0f);
                }
                else
                {
                    random_loc_x = new Vector3(Random.Range(-15, 15), 0f, 0f);
                }
            }
            else if (x_val > 35 && z_val < 90 && z_val > 60)
            {
                //left corner
                random_loc_z = new Vector3(0f, 0f, Random.Range(10f, 140f));
                if (random_loc_z.z < 90f && random_loc_z.z > 60f)
                {
                    random_loc_x = new Vector3(Random.Range(-45f, -65f), 0f, 0f);
                }
                else
                {
                    random_loc_x = new Vector3(Random.Range(-15f, 15f), 0f, 0f);
                }
            }
            else
            {
                //bottom corner
                random_loc_x = new Vector3(Random.Range(-65f, 65f), 0f, 0f);
                if (Math.Abs(random_loc_x.x) > 25)
                {
                    random_loc_z = new Vector3(0f, 0f, Random.Range(70f, 80f));
                }
                else
                {
                    random_loc_z = new Vector3(0f, 0f, Random.Range(10f, 30f));
                }
            }

            target.transform.localPosition = random_loc_z + random_loc_x;
        }
        else
        {
            agentRb.velocity = Vector3.zero;
            transform.rotation = Quaternion.Euler(new Vector3(0f, Random.Range(0, 360)));
            gameObject.transform.localPosition = start_pos;
        }

    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("goal"))
        {
            SetReward(2f);
            Done();
            print("target reached!");
        }
        else if(collision.gameObject.CompareTag("Player"))
        {
            SetReward(-1f);
            Done();
            print("collided with player");
        }
        else if (collision.gameObject.CompareTag("wall"))
        {
            SetReward(-1f);
            Done();
            print("collided with wall");
        }
    }

    public override void AgentOnDone()
    {

    }
}
