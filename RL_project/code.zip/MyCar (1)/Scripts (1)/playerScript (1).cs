﻿using System;
using MLAgents;
using UnityEngine;
using Random = UnityEngine.Random;
using System.Collections.Generic;

namespace UnityStandardAssets.Vehicles.Car
{
    public class playerScript : Agent
    {
        public GameObject[] rand_obst;
        public float accel_cur;
        public GameObject target;

        public int frames_count;

        public RayPerception ray_per;

        public int numRuns;

        public Vector3 start_pos;
        public Quaternion start_rot;
        public Vector3 start_forward;

        public string car_color;


        private Rigidbody m_Rigidbody;


        private bool[] reached_ring = { false, false, false };

        private float collide_penalty = -0.5f;

        private bool enable_reward_rings = false;

        private bool reward_getting_closer = true;

        private float prev_dist = 10000;

        public float cur_accel;

        private float base_dist_to_target;

        private List<float> prev_ray;

        public GameObject platform;

        public float max_x_pos, max_z_pos;

        private float gain_reward;

        private int count_succ = 0; //roy change

        private Vector3 target_orig_pos;    //roy change

        private bool rand_start_loc = true;
        private bool rand_obst_loc = true;
        private bool obst_move = true;

        private const float frame_pen = -0.0003f;


        //add new car
        private void CreateAgent()
        {
            print("CreateAgent");
            Vector3 position = start_pos + new Vector3(-10, 0, 0);
            GameObject AgentObj = Instantiate(gameObject, position, start_rot);
            Agent Agent = AgentObj.GetComponent<Agent>();
            Agent.GiveBrain(this.brain);
            Agent.AgentReset();
        }


        //my addition
        public override void InitializeAgent()
        {
            base.InitializeAgent();

            Monitor.SetActive(true);

            //
            //
            m_Rigidbody = GetComponent<Rigidbody>();
            frames_count = 0;
            numRuns = 0;
            start_pos = gameObject.transform.localPosition;     //roy change
            start_rot = gameObject.transform.localRotation;          //roy change
            start_forward = gameObject.transform.forward;

            target_orig_pos = target.transform.localPosition;
            print("rot = " + start_rot + " pos=" + start_pos);

            //ray perception
            ray_per = GetComponent<RayPerception3D>();

            const float ray_dist = 30f;
            float[] ray_angles = { 50, 70, 80, 90, 100, 110, 130 };
            string[] detectable_objects = { "Obstacle" };  //sees the target without rays
            prev_ray = ray_per.Perceive(ray_dist, ray_angles, detectable_objects, 0f, 0f);

            base_dist_to_target = Vector3.Distance(gameObject.transform.localPosition, target.transform.localPosition);
            prev_dist = base_dist_to_target;
            gain_reward = 0;
            count_succ = 0;
        }


        public override void AgentAction(float[] vectorAction, string textAction)
        {
            if (IsDone())
            {
                return;
            }
            //report to academy
            Monitor.Log(car_color + " reward", GetCumulativeReward(), null);
            //
            if (brain.brainParameters.vectorActionSpaceType == SpaceType.discrete)
            {
                var dirToGo = Vector3.zero;
                var rotateDir = Vector3.zero;
                switch (vectorAction[0])
                {
                    case 0:
                        dirToGo = Vector3.zero;
                        break;
                    case 1:
                        dirToGo = transform.forward * 1f;
                        break;
                    case 2:
                        dirToGo = transform.forward * -1f;
                        break;
                   
                }
                m_Rigidbody.AddForce(dirToGo * 2f, ForceMode.VelocityChange);
            }
            frames_count++;

            //penalty for quicker arrival
            //AddReward(frame_pen);
            AddReward(-1f / (agentParameters.maxStep));

            //dot product is like correlation between directions
            Vector3 dir2target = target.transform.position - gameObject.transform.position;
            //print("forward "+gameObject.transform.forward);
            //print("dir2target.normalized " + dir2target.normalized);
            float dot_product = Vector3.Dot(dir2target.normalized, m_Rigidbody.velocity) / (agentParameters.maxStep / 2);
            AddReward(dot_product);

            //reach target
            gain_reward += dot_product + m_Rigidbody.velocity.magnitude / agentParameters.maxStep;
            float dist_from_target = Vector3.Distance(gameObject.transform.position, target.transform.position);
            //reached target



            const float ray_dist = 30f;
            float[] ray_angles = { 50, 70, 80, 90, 100, 110, 130 };
            string[] detectable_objects = { "Obstacle" };  //sees the target without rays
            List<float> observations = ray_per.Perceive(ray_dist, ray_angles, detectable_objects, 0f, 0f);
            float count_observations = 0;
            for (int i = 0; i < observations.Count; i++)
            {
                count_observations += observations[i];
            }
            float reward_obstacles = (ray_angles.Length - count_observations) / ray_angles.Length;
            reward_obstacles = -1f * reward_obstacles / agentParameters.maxStep;
            AddReward(reward_obstacles);


            if (dist_from_target < 15)
            {
                AddReward(0.5f);
                print("frame count = " + frames_count);
                print(car_color + " car has reached target! reward: " + GetCumulativeReward() + " way reward " + gain_reward + " punish " + -1f * frames_count / (agentParameters.maxStep));
                count_succ++;
                Done();
                return;

            }


            if (frames_count >= agentParameters.maxStep - 1)
            {
                Done();
                print("wandering: reward : " + GetCumulativeReward() + " way reward " + gain_reward + " punish " + frame_pen * frames_count);
                return;

            }

            //move obstacles:
            if (obst_move)
            {
                for (int i = 0; i < rand_obst.Length; i++)
                {
                    double norm = Math.Sqrt(Math.Pow(rand_obst[i].transform.forward.x, 2) + Math.Pow(rand_obst[i].transform.forward.y, 2) + Math.Pow(rand_obst[i].transform.forward.z, 2));
                    rand_obst[i].transform.localPosition += (rand_obst[i].transform.forward) / 50 * (float)norm;
                }
            }


        }

        public override void CollectObservations()
        {
            //

            //rotation of car
            Vector3 dir2target = target.transform.position - gameObject.transform.position;

            AddVectorObs(dir2target.normalized);
            //print("direction_to_target " + direction_to_target);
            //AddVectorObs(gameObject.transform.forward);
            AddVectorObs(m_Rigidbody.velocity);

            //rays
            const float ray_dist = 30f;
            float[] ray_angles = { 50, 70, 80, 90, 100, 110, 130 };
            string[] detectable_objects = { "Obstacle" };  //sees the target without rays
            //add previous rays in order to detect differences
            AddVectorObs(prev_ray);
            prev_ray = ray_per.Perceive(ray_dist, ray_angles, detectable_objects, 0f, 0f);
            AddVectorObs(prev_ray);

        }

        public override void AgentReset()
        {
            gain_reward = 0;
            //randomize the position
            Vector3 random_delta_x = new Vector3(Random.Range(-15, 15), 0f, 0f);
            Vector3 random_loc_x;
            Vector3 random_loc_z;
            float rand_val = Random.Range(0f, 4f);

            //roy change
            if (count_succ > 0 && (rand_obst_loc || obst_move || rand_start_loc))
            {
                //
                gameObject.transform.localPosition = start_pos + new Vector3(Random.Range(-10f, 10f), 0f, Random.Range(-10f, 10f));


                gameObject.transform.forward = start_forward;//Quaternion.AngleAxis(Random.Range(-30f, 30f), start_forward);
                // randomize target
                count_succ = 0;
                float x_val = gameObject.transform.localPosition.x;
                float z_val = gameObject.transform.localPosition.z;

                if (Math.Abs(x_val) < 25 && z_val < 30)
                {
                    //top corner
                    random_loc_x = new Vector3(Random.Range(-65f, 65f), 0f, 0f);
                    if (Math.Abs(random_loc_x.x) > 25)
                    {
                        random_loc_z = new Vector3(0f, 0f, Random.Range(60f, 90f));
                    }
                    else
                    {
                        random_loc_z = new Vector3(0f, 0f, Random.Range(110f, 140f));
                    }
                }
                else if (x_val < -35 && z_val < 90 && z_val > 60)
                {
                    //right corner
                    random_loc_z = new Vector3(0f, 0f, Random.Range(10f, 140f));
                    if (random_loc_z.z < 90f && random_loc_z.z > 60f)
                    {
                        random_loc_x = new Vector3(Random.Range(45f, 65f), 0f, 0f);
                    }
                    else
                    {
                        random_loc_x = new Vector3(Random.Range(-25, 25), 0f, 0f);
                    }
                }
                else if (x_val > 35 && z_val < 90 && z_val > 60)
                {
                    //left corner
                    random_loc_z = new Vector3(0f, 0f, Random.Range(10f, 140f));
                    if (random_loc_z.z < 90f && random_loc_z.z > 60f)
                    {
                        random_loc_x = new Vector3(Random.Range(-45f, -65f), 0f, 0f);
                    }
                    else
                    {
                        random_loc_x = new Vector3(Random.Range(-25f, 25f), 0f, 0f);
                    }
                }
                else
                {
                    //bottom corner
                    random_loc_x = new Vector3(Random.Range(-65f, 65f), 0f, 0f);
                    if (Math.Abs(random_loc_x.x) > 25)
                    {
                        random_loc_z = new Vector3(0f, 0f, Random.Range(60f, 90f));
                    }
                    else
                    {
                        random_loc_z = new Vector3(0f, 0f, Random.Range(10f, 30f));
                    }
                }

                target.transform.localPosition = random_loc_z + random_loc_x;
            }
            else
            {
                gameObject.transform.localPosition = start_pos;
                gameObject.transform.forward = start_forward;
            }



            for (int i = 0; i < rand_obst.Length; i++)
            {
                rand_obst[i].transform.localPosition = new Vector3(Random.Range(-25f, 25f), 0f, Random.Range(50f, 100f));
                rand_obst[i].transform.localRotation = Quaternion.Euler(0f, Random.Range(-180f, 180f), 0f);      //roy change
            }

            m_Rigidbody.velocity = new Vector3(0f, 0f, 0f);
            frames_count = 0;
            numRuns++;


            const float ray_dist = 30f;
            float[] ray_angles = { 50, 70, 80, 90, 100, 110, 130 };
            string[] detectable_objects = { "Obstacle" };  //sees the target without rays
            prev_ray = ray_per.Perceive(ray_dist, ray_angles, detectable_objects, 0f, 0f);

            base_dist_to_target = Vector3.Distance(gameObject.transform.localPosition, target.transform.localPosition);
            prev_dist = base_dist_to_target;


        }

        //


        private void Awake()
        {

            // give the random perlin a random value
            m_Rigidbody = GetComponent<Rigidbody>();
        }

        public void OnCollisionEnter(Collision collision)
        {
            if (collision.gameObject.CompareTag("Obstacle"))
            {
                Done();
                AddReward((collide_penalty));
                print("collided obstacle! reward " + GetCumulativeReward());
                return;
            }
        }
    }
}

