using System;
using MLAgents;
using UnityEngine;
using Random = UnityEngine.Random;
using System.Collections.Generic;

namespace UnityStandardAssets.Vehicles.Car
{
    [RequireComponent(typeof (CarController))]

    public class CarAIControl : Agent
    {
        public GameObject[] rand_obst;
        public float accel_cur;
        public GameObject target;

        public int frames_count;

        public RayPerception ray_per;

        public int numRuns;

        public Vector3 start_pos;
        public Quaternion start_rot;
        public Vector3 start_forward;

        public string car_color;

        private CarController m_CarController;    // Reference to actual car controller we are controlling

        private Rigidbody m_Rigidbody;


        private bool[] reached_ring = { false, false, false };

        private float collide_penalty = -0.5f;

        private bool enable_reward_rings = false;

        private bool reward_getting_closer = true;

        private float prev_dist = 10000;

        public float cur_accel;

        private float base_dist_to_target;

        private List<float> prev_ray;

        public GameObject platform;

        public float max_x_pos, max_z_pos;

        private float gain_reward;

        private int count_succ = 0; //roy change

        private Vector3 target_orig_pos;    //roy change

        private bool rand_start_loc = true;
        private bool rand_obst_loc = true;
        private bool obst_move = true;

        private float frame_pen;



        //my addition
        public override void InitializeAgent()
        {
            base.InitializeAgent();

            Monitor.SetActive(true);

            //
            //
            frame_pen = -1f / agentParameters.maxStep;



            m_Rigidbody = gameObject.GetComponent<Rigidbody>();
            frames_count = 0;
            numRuns = 0;
            start_pos = gameObject.transform.localPosition;     //roy change
            start_rot = gameObject.transform.localRotation;          //roy change
            start_forward = gameObject.transform.forward;

            target_orig_pos = target.transform.localPosition;
            print("rot = "+ start_rot+" pos="+start_pos);

            //ray perception
            ray_per = GetComponent<RayPerception3D>();

            const float ray_dist = 30f;
            float[] ray_angles = { 50, 70, 80, 90, 100, 110, 130 };
            string[] detectable_objects = { "Obstacle" };  //sees the target without rays
            prev_ray = ray_per.Perceive(ray_dist, ray_angles, detectable_objects, 0f, 0f);

            base_dist_to_target = Vector3.Distance(gameObject.transform.localPosition, target.transform.localPosition);
            prev_dist = base_dist_to_target;
            gain_reward = 0;
            count_succ = 0;
        }


        public override void AgentAction(float[] vectorAction, string textAction)
        {
            if (IsDone())
            {
                return;
            }
            // report to academy
            Monitor.Log(car_color + " reward", GetCumulativeReward(), null);
            //
            if (brain.brainParameters.vectorActionSpaceType == SpaceType.discrete)
            {

                cur_accel = (vectorAction[1] - 1) / 2;
                m_CarController.Move((vectorAction[0] - 3) / 3, (vectorAction[1] - 1) / 2, 0f, 0f);
            }

            frames_count++;

            //penalty for quicker arrival
            AddReward(frame_pen);   //-1/max_step

            float dist_from_target = Vector3.Distance(gameObject.transform.position, target.transform.position);
            //reached target
            if (dist_from_target < 15)
            {
                Done();
                AddReward(0.5f);

                print("frame count = " + frames_count);
                print(car_color + " car has reached target! reward: " + GetCumulativeReward() + " way reward " + gain_reward + " punish " + frame_pen * frames_count);
                count_succ++;

            }
            float delta_diff = prev_dist - dist_from_target;
            gain_reward += delta_diff / base_dist_to_target;
            AddReward(delta_diff / base_dist_to_target);    //if reaching target - comulative reward is exactly and always 1
            //print("advancing reward " + delta_diff / base_dist_to_target);

            prev_dist = dist_from_target;


            if (frames_count >= 9999)
            {
                Done();
                AddReward(-0.1f);
                print("wandering: reward : " + GetCumulativeReward() + " way reward " + gain_reward + " punish " + frame_pen * frames_count);

            }

            //move obstacles:
            if (obst_move)
            {
                for (int i = 0; i < rand_obst.Length; i++)
                {
                    double norm = Math.Sqrt(Math.Pow(rand_obst[i].transform.forward.x, 2) + Math.Pow(rand_obst[i].transform.forward.y, 2) + Math.Pow(rand_obst[i].transform.forward.z, 2));
                    rand_obst[i].transform.localPosition += (rand_obst[i].transform.forward) / 50 * (float)norm;
                }
            }



        }

        public override void CollectObservations()
        {
            //rotation of car
            var heading = target.transform.position - gameObject.transform.position;
            var distance = heading.magnitude;
            var direction_to_target = heading / distance; // This is now the normalized direction.
            AddVectorObs(direction_to_target);
            //print("direction_to_target " + direction_to_target);
            AddVectorObs(gameObject.transform.forward);
            //print("gameObject.transform.forward " + gameObject.transform.forward);
            //dist
            float dist_to_target = Vector3.Distance(gameObject.transform.position, target.transform.position);
            float dist_2_target_norm = dist_to_target / (float)Math.Sqrt((platform.GetComponent<Renderer>().bounds.size.x * platform.GetComponent<Renderer>().bounds.size.x)
             + (platform.GetComponent<Renderer>().bounds.size.z * platform.GetComponent<Renderer>().bounds.size.z));
            AddVectorObs(dist_2_target_norm);
            //print("dist_2_target_norm " + dist_2_target_norm);
            //rays
            const float ray_dist = 30f;
            float[] ray_angles = { 50, 70, 80, 90, 100, 110, 130 };
            string[] detectable_objects = { "Obstacle" };  //sees the target without rays
            //add previous rays in order to detect differences
            AddVectorObs(prev_ray); 
            for (int i = 0; i < prev_ray.Count; i++)
            {
                //print("prev_ray " + prev_ray[i]);
            }

            prev_ray = ray_per.Perceive(ray_dist, ray_angles, detectable_objects, 0f, 0f);
            AddVectorObs(prev_ray);

        }

        public override void AgentReset()
        {
            gain_reward = 0;
            //randomize the position
            Vector3 random_delta_x = new Vector3(Random.Range(-15, 15), 0f, 0f);
            Vector3 random_loc_x;
            Vector3 random_loc_z;
            float rand_val = Random.Range(0f, 4f);

            //roy change
            if (count_succ >= 0 && (rand_obst_loc||obst_move|| rand_start_loc))
            {
                //
                gameObject.transform.localPosition = start_pos +new Vector3(Random.Range(-10f, 10f), 0f, Random.Range(-10f, 10f));


                gameObject.transform.forward = start_forward;//Quaternion.AngleAxis(Random.Range(-30f, 30f), start_forward);
                // randomize target
                count_succ = 0;
                float x_val = gameObject.transform.localPosition.x;
                float z_val = gameObject.transform.localPosition.z;

                if (Math.Abs(x_val)<25 && z_val<30)
                {
                    //top corner
                    random_loc_x = new Vector3(Random.Range(-65f, 65f), 0f, 0f);
                    if (Math.Abs(random_loc_x.x) > 25)
                    {
                        random_loc_z  = new Vector3(0f, 0f, Random.Range(60f, 90f));
                    }
                    else
                    {
                        random_loc_z = new Vector3(0f, 0f, Random.Range(110f, 140f));
                    }
                }
                else if (x_val<-35 && z_val<90 && z_val>60)
                {
                    //right corner
                    random_loc_z = new Vector3( 0f, 0f, Random.Range(10f, 140f));
                    if (random_loc_z.z<90f && random_loc_z.z>60f)
                    {
                        random_loc_x = new Vector3(Random.Range(45f, 65f), 0f, 0f);
                    }
                    else
                    {
                        random_loc_x = new Vector3(Random.Range(-25, 25), 0f, 0f);
                    }
                }
                else if (x_val > 35 && z_val < 90 && z_val > 60)
                {
                    //left corner
                    random_loc_z = new Vector3(0f, 0f, Random.Range(10f, 140f));
                    if (random_loc_z.z < 90f && random_loc_z.z > 60f)
                    {
                        random_loc_x = new Vector3(Random.Range(-45f, -65f), 0f, 0f);
                    }
                    else
                    {
                        random_loc_x = new Vector3(Random.Range(-25f, 25f), 0f, 0f);
                    }
                }
                else
                {
                    //bottom corner
                    random_loc_x = new Vector3(Random.Range(-65f, 65f), 0f, 0f);
                    if (Math.Abs(random_loc_x.x) > 25)
                    {
                        random_loc_z = new Vector3(0f, 0f, Random.Range(60f, 90f));
                    }
                    else
                    {
                        random_loc_z = new Vector3(0f, 0f, Random.Range(10f, 30f));
                    }
                }

                target.transform.localPosition = random_loc_z + random_loc_x;
            }
            else
            {
                gameObject.transform.localPosition = start_pos;
                gameObject.transform.forward = start_forward;
            }

            

            for (int i = 0; i < rand_obst.Length; i++)
            {
                rand_obst[i].transform.localPosition = new Vector3(Random.Range(-25f, 25f), 0f, Random.Range(50f, 100f));
                rand_obst[i].transform.localRotation = Quaternion.Euler(0f, Random.Range(-180f, 180f), 0f);      //roy change
            }

            m_Rigidbody.velocity = new Vector3(0f, 0f, 0f);
            frames_count = 0;
            numRuns++;


            const float ray_dist = 30f;
            float[] ray_angles = { 50, 70, 80, 90, 100, 110, 130 };
            string[] detectable_objects = { "Obstacle" };  //sees the target without rays
            prev_ray = ray_per.Perceive(ray_dist, ray_angles, detectable_objects, 0f, 0f);

            base_dist_to_target = Vector3.Distance(gameObject.transform.localPosition, target.transform.localPosition);
            prev_dist = base_dist_to_target;


        }

        //


        private void Awake()
        {
            // get the car controller reference
            m_CarController = GetComponent<CarController>();

            // give the random perlin a random value
            m_Rigidbody = GetComponent<Rigidbody>();
        }
        
        public void OnCollisionEnter(Collision collision)
        {
            if (collision.gameObject.CompareTag("Obstacle"))
            {
                Done();
                AddReward(-0.1f);
                print("collided obstacle! reward "+ GetCumulativeReward());
                return;
            }
            else 
            {
                Done();
                //AddReward((collide_penalty/2));
                print("unresolved collision of car " + car_color+ " with object name "+collision.gameObject.name);
            }
        }
    }
}

